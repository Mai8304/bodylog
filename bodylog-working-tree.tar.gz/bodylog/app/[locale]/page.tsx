export default function Home() {
  return (
    <main className="flex min-h-[60vh] items-center justify-center p-10 text-center">
      <div>
        <h1 className="text-3xl font-semibold">BodyLog</h1>
        <p className="mt-2 text-muted-foreground">上传体检报告，自动结构化并获取 AI 健康建议。</p>
      </div>
    </main>
  )
}
