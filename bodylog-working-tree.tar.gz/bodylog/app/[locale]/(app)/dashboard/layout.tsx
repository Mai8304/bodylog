import type { ReactNode } from 'react'

import { DashboardShell, type DashboardNavConfigItem } from '@/components/layout/dashboard-shell'

const navItems: DashboardNavConfigItem[] = [
  { titleKey: 'overview', href: '/dashboard', icon: 'overview' },
  { titleKey: 'upload', href: '/dashboard/upload', icon: 'upload' },
  { titleKey: 'reports', href: '/dashboard/reports', icon: 'reports' },
  { titleKey: 'analytics', href: '/dashboard/analytics', icon: 'analytics' },
  { titleKey: 'settings', href: '/dashboard/settings', icon: 'settings' }
]

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return <DashboardShell navItems={navItems}>{children}</DashboardShell>
}
